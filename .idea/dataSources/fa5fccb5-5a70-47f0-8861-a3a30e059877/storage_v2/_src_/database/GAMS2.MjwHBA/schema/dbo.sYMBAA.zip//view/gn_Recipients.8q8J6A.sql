
CREATE view [dbo].[gn_Recipients]
as

select
	n.id,
	n.email,
	isnull(case when apa.id is not null then apa.txt_ap_vorname
		when tpa.id is not null then tpa.txt_tp_vorname
		else n.vorname end, '') as FirstName,
	isnull(case when apa.id is not null then apa.txt_ap_name
		when tpa.id is not null then tpa.txt_tp_name
		else n.nachname end, '') as LastName,
	isnull(case when apa.id is not null then apar.txt_anrede_de
		when tpa.id is not null then tpar.txt_anrede_de
		else nar.txt_anrede_de end, '') as Title,
	n.angemeldet as RegisteredOn,
	n.abgemeldet as BlackListedOn
from dbo.t_newsletter_email n
	left join dbo.t_anrede nar on n.anrede = nar.id
	left join
	(
		select recipient_id, max(address_id) as address_id
		from dbo.gn_RecipientsWithAPData WITH (NOEXPAND)
		group by recipient_id
	) as apids on n.id = apids.recipient_id
	left join dbo.t_adresse apa on apa.id = apids.address_id
	left join dbo.t_anrede apar on apa.int_ap_anrede_id = apar.id
	left join
	(
		select recipient_id, max(address_id) as address_id
		from dbo.gn_RecipientsWithTPData WITH (NOEXPAND)
		group by recipient_id
	) as tpids on n.id = tpids.recipient_id
	left join dbo.t_adresse tpa on tpa.id = tpids.address_id
	left join dbo.t_anrede tpar on tpa.int_tp_anrede_id = tpar.id
GO

