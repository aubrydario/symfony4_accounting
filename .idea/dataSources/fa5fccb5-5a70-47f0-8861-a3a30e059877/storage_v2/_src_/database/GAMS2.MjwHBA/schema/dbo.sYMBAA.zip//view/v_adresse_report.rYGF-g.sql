CREATE VIEW dbo.v_adresse_report
AS
SELECT     dbo.t_adresse.ID AS adresse_ID, dbo.t_adresse.txt_firma, dbo.t_plz.ort_27, dbo.t_adresse.txt_www, dbo.t_besitzer.t_user_ID, dbo.t_besitzer.freigabe, 
                      dbo.t_land.ID AS land_ID, dbo.t_kanton.ID AS kanton_ID, dbo.t_sub_branche.ID AS sub_branche_ID, dbo.t_plz.plz, dbo.t_branche.ID AS branche_ID, 
                      dbo.t_adresse.int_adress_status_ID AS int_adress_status_id
FROM         dbo.t_adresse_sub_branche RIGHT OUTER JOIN
                      dbo.t_plz RIGHT OUTER JOIN
                      dbo.t_adresse ON dbo.t_plz.ID = dbo.t_adresse.int_plz_ID LEFT OUTER JOIN
                      dbo.t_kanton ON dbo.t_plz.t_kanton_ID = dbo.t_kanton.ID LEFT OUTER JOIN
                      dbo.t_land ON dbo.t_kanton.t_land_ID = dbo.t_land.ID LEFT OUTER JOIN
                      dbo.t_besitzer ON dbo.t_adresse.ID = dbo.t_besitzer.t_adresse_ID ON dbo.t_adresse_sub_branche.t_adresse_ID = dbo.t_adresse.ID LEFT OUTER JOIN
                      dbo.t_sub_branche ON dbo.t_adresse_sub_branche.t_sub_branche_ID = dbo.t_sub_branche.ID LEFT OUTER JOIN
                      dbo.t_branche ON dbo.t_sub_branche.t_branche_ID = dbo.t_branche.ID
WHERE     (dbo.t_adresse.int_adress_status_ID > 8)
GO

