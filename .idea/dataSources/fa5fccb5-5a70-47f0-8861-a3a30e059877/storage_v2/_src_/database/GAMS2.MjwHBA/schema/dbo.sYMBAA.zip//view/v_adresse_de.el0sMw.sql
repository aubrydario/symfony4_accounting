CREATE VIEW dbo.v_adresse_de
AS
SELECT     dbo.t_adresse.ID, dbo.t_adresse.int_adress_status_ID, dbo.t_sprache.txt_sprache_de AS firma_sprache, dbo.t_land.txt_kuerzel_de AS land_kuerzel, 
                      dbo.t_kanton.txt_kuerzel_de AS kanton_kuerzel, dbo.t_adresse.txt_firma AS firma, dbo.t_adresse.txt_firma_zusatz AS firma_zusatz, 
                      dbo.t_user.vorname AS user_vorname, dbo.t_user.name AS user_name, dbo.t_adresse.txt_strasse AS strasse, dbo.t_adresse.txt_hausnr AS hausnr, 
                      dbo.t_plz.plz, dbo.t_plz.ort_27 AS ort, dbo.t_adresse.int_telefon_vorwahl AS firma_tel_vorwahl, dbo.t_adresse.int_telefon AS firma_tel, 
                      dbo.t_adresse.int_fax_vorwahl AS firma_fax_vorwahl, dbo.t_adresse.int_fax AS firma_fax, dbo.t_adresse.txt_firma_email AS firma_email, 
                      dbo.t_adresse.txt_www AS firma_www, dbo.t_adresse.txt_alt_www AS firma_alt_www, dbo.t_branche.txt_branche_de AS branche, 
                      dbo.t_sub_branche.txt_sub_branche_de AS sub_branche, dbo.t_adresse.txt_bemerkung AS bemerkung, dbo.t_anrede.txt_anrede_de AS ap_anrede, 
                      dbo.t_funktion.txt_funktion_de AS ap_funktion, dbo.t_titel.txt_titel_de AS ap_titel, dbo.t_adresse.txt_ap_vorname AS ap_vorname, 
                      dbo.t_adresse.txt_ap_name AS ap_name, dbo.t_adresse.txt_ap_email AS ap_email, dbo.t_adresse.int_ap_direktwahl_vorwahl AS ap_tel_vorwahl, 
                      dbo.t_adresse.int_ap_direktwahl AS ap_tel, dbo.t_adresse.int_ap_mobile_vorwahl AS ap_mobile_vorwahl, dbo.t_adresse.int_ap_mobile AS ap_mobile, 
                      dbo.t_adresse.txt_tp_firma AS tp_firma, dbo.t_adresse.txt_tp_www AS tp_www, t_anrede_1.txt_anrede_de AS tp_anrede, 
                      t_funktion_1.txt_funktion_de AS tp_funktion, t_titel_1.txt_titel_de AS tp_titel, dbo.t_adresse.txt_tp_vorname AS tp_vorname, 
                      dbo.t_adresse.txt_tp_name AS tp_name, dbo.t_adresse.txt_tp_email AS tp_email, dbo.t_adresse.int_tp_direktwahl_vorwahl AS tp_tel_vorwahl, 
                      dbo.t_adresse.int_tp_direktwahl AS tp_tel, dbo.t_adresse.int_tp_mobile_vorwahl AS tp_mobile_vorwahl, dbo.t_adresse.int_tp_mobile AS tp_mobile, 
                      dbo.t_kanton.txt_kanton_de AS kanton, dbo.t_land.txt_land_vorwahl AS land_vorwahl, dbo.t_adresse.int_firma_sprache_ID AS firma_sprache_ID, 
                      dbo.t_adresse.int_ap_anrede_ID AS ap_anrede_ID, dbo.t_adresse.int_ap_titel_ID AS ap_titel_ID, dbo.t_adresse.int_ap_funktion_ID AS ap_funktion_ID, 
                      dbo.t_adresse.int_tp_anrede_ID AS tp_anrede_ID, dbo.t_adresse.int_tp_titel_ID AS tp_titel_ID, dbo.t_adresse.int_tp_funktion_ID AS tp_funktion_ID, 
                      dbo.t_sub_branche.ID AS sub_branche_ID, dbo.t_branche.ID AS branche_ID, dbo.t_land.ID AS land_ID, dbo.t_adresse.int_land_ID AS adresse_land_ID, 
                      dbo.t_adresse.int_kanton_ID AS adresse_kanton_ID, dbo.t_adresse.int_plz_ID AS adresse_plz_ID, dbo.t_besitzer.freigabe, dbo.t_adresse.kundenart, 
                      dbo.t_adresse.bonitaetsstatus, dbo.t_adresse.t_anz_ma, dbo.t_adresse.t_umsatz
FROM         dbo.t_user RIGHT OUTER JOIN
                      dbo.t_adresse_sub_branche RIGHT OUTER JOIN
                      dbo.t_plz RIGHT OUTER JOIN
                      dbo.t_adresse ON dbo.t_plz.ID = dbo.t_adresse.int_plz_ID LEFT OUTER JOIN
                      dbo.t_kanton ON dbo.t_plz.t_kanton_ID = dbo.t_kanton.ID LEFT OUTER JOIN
                      dbo.t_land ON dbo.t_kanton.t_land_ID = dbo.t_land.ID LEFT OUTER JOIN
                      dbo.t_besitzer ON dbo.t_adresse.ID = dbo.t_besitzer.t_adresse_ID ON dbo.t_adresse_sub_branche.t_adresse_ID = dbo.t_adresse.ID LEFT OUTER JOIN
                      dbo.t_sub_branche ON dbo.t_adresse_sub_branche.t_sub_branche_ID = dbo.t_sub_branche.ID ON 
                      dbo.t_user.ID = dbo.t_besitzer.t_user_ID LEFT OUTER JOIN
                      dbo.t_sprache ON dbo.t_adresse.int_firma_sprache_ID = dbo.t_sprache.ID LEFT OUTER JOIN
                      dbo.t_branche ON dbo.t_sub_branche.t_branche_ID = dbo.t_branche.ID LEFT OUTER JOIN
                      dbo.t_anrede ON dbo.t_adresse.int_ap_anrede_ID = dbo.t_anrede.ID LEFT OUTER JOIN
                      dbo.t_funktion ON dbo.t_adresse.int_ap_funktion_ID = dbo.t_funktion.ID LEFT OUTER JOIN
                      dbo.t_titel ON dbo.t_adresse.int_ap_titel_ID = dbo.t_titel.ID LEFT OUTER JOIN
                      dbo.t_anrede AS t_anrede_1 ON dbo.t_adresse.int_tp_anrede_ID = t_anrede_1.ID LEFT OUTER JOIN
                      dbo.t_funktion AS t_funktion_1 ON dbo.t_adresse.int_tp_funktion_ID = t_funktion_1.ID LEFT OUTER JOIN
                      dbo.t_titel AS t_titel_1 ON dbo.t_adresse.int_tp_titel_ID = t_titel_1.ID
WHERE     (dbo.t_adresse.adresse_ungueltig = 0)
GO

