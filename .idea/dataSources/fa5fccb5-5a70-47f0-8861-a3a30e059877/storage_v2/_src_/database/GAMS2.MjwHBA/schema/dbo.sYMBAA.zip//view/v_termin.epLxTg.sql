CREATE VIEW dbo.v_termin
AS
SELECT     TOP (100) PERCENT dbo.t_termin.id, dbo.t_termin.von, dbo.t_termin.bis, dbo.t_termin.t_adresse_id, dbo.t_termin.bemerkungen, 
                      dbo.t_termin_status.status_txt, dbo.t_termin.CA_id, dbo.t_termin.AG_id, dbo.t_plz.ort_27 AS txt_ort, dbo.t_plz.plz, dbo.t_adresse.txt_firma
FROM         dbo.t_termin LEFT OUTER JOIN
                      dbo.t_adresse ON dbo.t_termin.t_adresse_id = dbo.t_adresse.ID LEFT OUTER JOIN
                      dbo.t_termin_status ON dbo.t_termin.status = dbo.t_termin_status.ID LEFT OUTER JOIN
                      dbo.t_plz ON dbo.t_adresse.int_plz_ID = dbo.t_plz.ID
WHERE     (dbo.t_termin.del = 0) AND (dbo.t_adresse.adresse_ungueltig IS NULL OR
                      dbo.t_adresse.adresse_ungueltig = '' OR
                      dbo.t_adresse.adresse_ungueltig = 0)
ORDER BY dbo.t_termin.von
GO

