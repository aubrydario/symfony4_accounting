CREATE FUNCTION istemailgueltig
(
	@email nvarchar(100)
)
RETURNS bit
AS
BEGIN
	DECLARE @isValid bit;
	
	-- Add the T-SQL statements to compute the return value here
	SELECT @isValid = 1
	WHERE
	(
		CHARINDEX(' ',LTRIM(RTRIM(@email))) = 0 
		AND  	LEFT(LTRIM(@email),1) <> '@' 
		AND  	RIGHT(RTRIM(@email),1) <> '.' 
		AND  	CHARINDEX('.',@email,CHARINDEX('@',@email)) - CHARINDEX('@',@email) > 1 
		AND  	LEN(LTRIM(RTRIM(@email))) - LEN(REPLACE(LTRIM(RTRIM(@email)),'@','')) = 1 
		AND  	CHARINDEX('.',REVERSE(LTRIM(RTRIM(@email)))) >= 3 
		AND  	(CHARINDEX('.@',@email) = 0 AND CHARINDEX('..',@email) = 0)
	)

	-- Return the result of the function
	RETURN isnull(@isValid, 0);
END
GO

