CREATE procedure [dbo].[dt_insert_adress_bestaetigung_count]
@t_user_id int,
@t_adresse_id int

AS
SET NOCOUNT ON


	if exists(Select ID from t_adresse_bestaetigung_count where t_user_id = @t_user_id and t_adresse_id = @t_adresse_id )
		BEGIN
				select @t_adresse_id
		END
	else
		BEGIN
				Insert into t_adresse_bestaetigung_count (t_user_id,t_adresse_id) values (@t_user_id,@t_adresse_id)
		END
GO

