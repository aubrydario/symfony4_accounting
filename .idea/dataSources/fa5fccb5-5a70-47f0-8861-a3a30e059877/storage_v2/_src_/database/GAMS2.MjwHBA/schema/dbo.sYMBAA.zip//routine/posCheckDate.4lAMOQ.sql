
CREATE FUNCTION dbo.posCheckDate  (@txt_www varchar(500))

RETURNS @temp TABLE
(
ID	int,
datum 	datetime
)
AS
BEGIN

declare @anz int

select @anz = t_report.ID from t_report WHERE URL like '%' + @txt_www + '%' ORDER by ID DESC

if @anz = NULL 
BEGIN 
INSERT INTO @temp(ID, datum) VALUES(1, '01.01.1995')

END
ELSE
BEGIN

	INSERT @temp

	SELECT top 1 t_report.ID, t_report.date from t_report WHERE URL like '%' + @txt_www + '%' ORDER by ID DESC
	
END

	RETURN
END


GO

