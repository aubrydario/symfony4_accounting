-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GAMSStatistik](@von datetime,@bis datetime,@modus int,@t_user_id int)  

RETURNS int
AS
BEGIN
declare @anzahl int
declare @date_erfassung smalldatetime
declare @anruf nvarchar(150)
set @anzahl = 0
declare stat_cursor cursor for 
select @anruf, @date_erfassung from t_history where t_user_id = @t_user_id
open stat_cursor
fetch next from stat_cursor into @anruf, @date_erfassung
while @@fetch_status = 0
begin
	
	if @date_erfassung between @von AND @bis
	BEGIN 
		if @anruf = 'Anruf angenommen'  	
		BEGIN
		set @anzahl = @anzahl + 1
		END 
	END 
fetch next from stat_cursor into @anruf, @date_erfassung
end

return @anzahl
END
GO

