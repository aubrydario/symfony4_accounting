
CREATE VIEW [dbo].[gn_NotTechnicalAddresses]
WITH SCHEMABINDING
AS
	select
		n.id as recipient_id,
		a.id as address_id
	from dbo.t_newsletter_email n
		join dbo.t_adresse a on n.email = a.txt_firma_email or n.email = a.txt_ap_email
	where n.abgemeldet is null and (a.adresse_ungueltig is null or a.adresse_ungueltig = 0)
GO

