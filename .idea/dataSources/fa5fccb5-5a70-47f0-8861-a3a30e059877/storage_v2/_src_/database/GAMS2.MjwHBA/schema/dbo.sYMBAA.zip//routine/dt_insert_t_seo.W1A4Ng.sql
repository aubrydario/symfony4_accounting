

CREATE procedure [dbo].[dt_insert_t_seo]

@t_url_id					int,
@t_user_id					int,
@begin_optimierung			datetime,
@optimierung_bereit			datetime,
@optimierung_aufgeschaltet	datetime,
@kunde_metas_zusenden		datetime,
@seo_bemerkung				nvarchar(2000),
@mit_doorway				int,
@alt_text_einf				int,
@zusatzseiten				int,
@sitemap				int,
@anm_open_dir				int,
@seo_art					int


AS

SET NOCOUNT ON

declare @temp_kw_id int
declare @temp_kw_vorschlag_id int
declare @temp_txt_www nvarchar(50)
declare @temp_t_adresse_id int


BEGIN
		/* jede SEO wird dem neutralen User zugewiesen (id=331) */ 
		/*Insert into t_kw (t_user_id) values (@t_user_id)*/
		Insert into t_kw (t_user_id) values (331)
	 			set @temp_kw_id = Scope_Identity()
	 			
		/*Insert into t_kw_vorschlag (t_user_id) values (@t_user_id)*/
		Insert into t_kw_vorschlag (t_user_id) values (331)
	 			set @temp_kw_vorschlag_id = Scope_Identity()
		
Insert into t_seo(t_user_id,t_url_id,begin_optimierung,optimierung_bereit,optimierung_aufgeschaltet,kunde_metas_zusenden,t_kw_vorschlag_id,t_kw_id,bemerkung,mit_doorway,alt_text_einf,zusatzseiten,sitemap,anm_open_dir, t_seo_art_ID)  
	   values (331,@t_url_id,@begin_optimierung,@optimierung_bereit,@optimierung_aufgeschaltet,@kunde_metas_zusenden,@temp_kw_vorschlag_id,@temp_kw_id,@seo_bemerkung,@mit_doorway,@alt_text_einf,@zusatzseiten,@sitemap,@anm_open_dir, @seo_art)

/* Poscheck-Status autom. auf grün setzen, damit keine SEO mehr verloren gehen kann 
update t_url set pos_check = 1 where id = @t_url_id	

automatisch einen Check bestellen  
select @temp_txt_www = txt_www, @temp_t_adresse_id = t_adresse_id from t_url where id = @t_url_id

insert into t_report_status(t_url_id, txt_www, in_bearbeitung, prio, best_date, best_uid, t_adresse_id) 
VALUES (@t_url_id, @temp_txt_www, 0, 3, GETDATE(), 251, @temp_t_adresse_id)
*/

END


GO

