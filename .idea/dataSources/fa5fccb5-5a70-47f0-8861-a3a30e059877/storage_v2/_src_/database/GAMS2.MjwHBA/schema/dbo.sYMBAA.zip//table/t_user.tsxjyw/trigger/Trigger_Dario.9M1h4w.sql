-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description: <Description,,>
-- =============================================
CREATE TRIGGER [dbo].[Trigger_Dario] ON [dbo].[t_user]
	FOR INSERT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	UPDATE t_user 
	SET GultigBis = DATEADD(year, 5, GultigBis) 
	WHERE ID =( SELECT max(ID) FROM t_user )

END
GO

