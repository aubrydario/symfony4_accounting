

CREATE  procedure [dbo].[dt_insert_element_add]

@typeID	int,
@ID		int,
@keywords	varchar(200)

AS
SET NOCOUNT ON

DECLARE  @temp_id  INT 
	if exists(Select id from t_keywords_set where keywords = @keywords)
		BEGIN
				SET @temp_id = (Select id from t_keywords_set where keywords = @keywords)
		END
	else 
		BEGIN
				Insert into  t_keywords_set (keywords) values (@keywords)
				SET @temp_id = Scope_Identity()
   		 END


if (@typeID = 1) 
BEGIN
	if not exists(Select t_keywords_set_id from t_keywords_additional where t_keywords_set_id = @temp_id and t_kw_vorschlag_id = @ID)
		BEGIN
				Insert into t_keywords_additional (t_keywords_set_id, t_kw_vorschlag_id, t_kw_id) values (@temp_id, @ID, NULL) 
		END
If not exists(Select id from t_kw_vorschlag_spec where t_kw_vorschlag_id = @ID and t_keywords_set_id = @temp_id)
	BEGIN
		INSERT t_kw_vorschlag_spec (t_kw_vorschlag_id,t_keywords_set_id) VALUES (@ID, @temp_id )
	END
END

if (@typeID = 2)
BEGIN
if not exists(Select t_keywords_set_id from t_keywords_additional where t_keywords_set_id = @temp_id and t_kw_id = @ID)
	BEGIN
			Insert into t_keywords_additional (t_keywords_set_id, t_kw_vorschlag_id, t_kw_id) values (@temp_id, NULL, @ID) 
	END
If not exists(Select id from t_kw_spec where t_kw_id = @ID and t_keywords_set_id = @temp_id)
	BEGIN
		/*INSERT t_kw_spec (t_kw_id,t_keywords_set_id) VALUES (@ID, @temp_id )*/
		DELETE from  t_kw_spec where t_kw_id = @ID and t_keywords_set_id= @temp_id 
	END
END
GO

