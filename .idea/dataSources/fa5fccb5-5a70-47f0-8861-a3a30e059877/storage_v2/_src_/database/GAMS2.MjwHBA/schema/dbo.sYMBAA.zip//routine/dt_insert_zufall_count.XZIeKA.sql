CREATE procedure [dbo].[dt_insert_zufall_count]

@t_user_id int,
@datum smalldatetime

AS
SET NOCOUNT ON


	if exists(Select t_user_id from t_zufall_count where t_user_id = @t_user_id and datum = @datum)
		BEGIN
				Update t_zufall_count SET zufall_count = zufall_count + 1 where t_user_id = @t_user_id and datum = @datum
		END
	else
		BEGIN
				Insert into t_zufall_count (t_user_id,zufall_count,datum) values (@t_user_id,1,@datum)
		END
GO

