-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[count_SEO_Dario]
(
	@userid int
	,@month int
	,@year int
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @anzahl int;

	-- Add the T-SQL statements to compute the return value here
	SELECT @anzahl = count(optimierung_aufgeschaltet) 
	FROM t_seo
	INNER JOIN t_user ON t_user.id = t_seo.t_user_id
	WHERE @userid = t_user.id 
		AND @month = month(optimierung_aufgeschaltet) 
		AND @year = year(optimierung_aufgeschaltet)

	-- Return the result of the function
	RETURN @anzahl

END
GO

