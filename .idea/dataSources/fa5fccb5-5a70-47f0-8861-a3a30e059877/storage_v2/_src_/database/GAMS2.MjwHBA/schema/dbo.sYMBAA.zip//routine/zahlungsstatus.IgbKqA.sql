
/*
status : 
1 - zahlung ok, also weiter optimieren
0 - betrieben,gekündigt  o.ä. - dann nix machen
*/


CREATE FUNCTION [dbo].[zahlungsstatus] (@t_url_id int)  
RETURNS int  AS
BEGIN 

DECLARE @status int
DECLARE @betrieben datetime
DECLARE @rechtsvorschlag datetime
DECLARE @unterlagen datetime
DECLARE @fortsetzung datetime
DECLARE @forderungseingabe datetime
DECLARE @bezahlt datetime
DECLARE @storniert datetime
DECLARE @abgeschrieben datetime
DECLARE @firmenstatus varchar(50)
DECLARE @gekuendigt datetime
DECLARE @heute datetime

SELECT @heute = heute from v_heute
set @status = 0	

SELECT 
@betrieben = betrieben,
@rechtsvorschlag = rechtsvorschlag,
@unterlagen = unterlagen,
@fortsetzung = fortsetzung,
@forderungseingabe = forderungseingabe,
@bezahlt = bezahlt,
@storniert = storniert,
@abgeschrieben = abgeschrieben,
@firmenstatus = firmenstatus
from t_zahlungstatus
where 
t_url_id = @t_url_id
	
/* Wenn alle Felder leer sind */
IF (@betrieben IS NULL AND @rechtsvorschlag IS NULL AND @unterlagen IS NULL AND @fortsetzung IS NULL AND @forderungseingabe IS NULL AND @bezahlt IS NULL AND @storniert IS NULL AND @abgeschrieben IS NULL AND @firmenstatus IS NULL ) 
BEGIN
	set @status = 1
END
ELSE
BEGIN 
	/* prüfen, ob bezahlt*/
	IF(@bezahlt is NULL)
	BEGIN
		set @status = 0	
	END
	ELSE
	BEGIN
		set @status = 1
	END
END

/* SELECT top 1 @gekuendigt = gekuendigt FROM t_vertrag_typ where t_url_id = @t_url_id AND gekuendigt <= @heute order by id desc */

SELECT top 1 @gekuendigt = gekuendigt FROM t_vertrag_typ where t_url_id = @t_url_id order by id desc

IF @gekuendigt IS NOT NULL and @gekuendigt >= @heute
BEGIN
	set @status = 0	
END


RETURN @status


END
GO

