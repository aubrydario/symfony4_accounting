

CREATE  procedure [dbo].[dt_insert_t_url_access]

@txt_www			nvarchar(50),
@t_adresse_id		int,
@vertragsstart		datetime,
@vertragsende		datetime,
@vertragsdauer		int,
@kundenblatversand	datetime,
@gratis_monate		int,
@gekuendigt			datetime,
@auftragsnummer		nvarchar(50),
@vertrag_bemerkung	nvarchar(2000),
@ftp_id				nvarchar(100),
@ft_host			nvarchar(100),
@ftp_passwort		nvarchar(100)


AS

SET NOCOUNT ON

declare @temp_hosting_id int
declare @temp_email_id int
declare @temp_url_id int

if (@vertragsstart = '') 
	BEGIN
		set @vertragsstart = NULL
	END
	
if (@vertragsende = '') 
	BEGIN
		set @vertragsende = NULL
	END
	
if (@kundenblatversand = '') 
	BEGIN
		set @kundenblatversand = NULL
	END
	
if (@gekuendigt = '') 
	BEGIN
		set @gekuendigt = NULL
	END
else
	BEGIN
		if @gekuendigt <= GETDATE()
			BEGIN
				Update t_adresse Set int_adress_status_ID = 12 Where id = @t_adresse_id
			END
	END

BEGIN
	if exists (select id from t_url where txt_www = @txt_www)

		BEGIN

		set @temp_url_id = (select id from t_url where txt_www = @txt_www)

		END

	else

		BEGIN
			Insert into t_hosting (passwort,benutzer,host,beiUns) values (@ftp_passwort,@ftp_id,@ft_host,0)

	 		set @temp_hosting_id = Scope_Identity()

			Insert into t_email (bemerkung) values (NULL)

	 		set @temp_email_id = Scope_Identity()



		Insert into t_url (t_hosting_id,t_email_id,t_adresse_id,txt_www) values (@temp_hosting_id,@temp_email_id,@t_adresse_id,@txt_www)

	 	set @temp_url_id = Scope_Identity()

		END

	Insert into t_vertrag_typ (vertragsdauer,vertragsstart,vertragsende,gekuendigt,kundenblatversand,bemerkung,gratis_monate,auftragsnummer,t_url_id) values (@vertragsdauer,@vertragsstart,@vertragsende,@gekuendigt,@kundenblatversand,@vertrag_bemerkung,@gratis_monate,@auftragsnummer,@temp_url_id)


		Select @temp_url_id


END


GO

