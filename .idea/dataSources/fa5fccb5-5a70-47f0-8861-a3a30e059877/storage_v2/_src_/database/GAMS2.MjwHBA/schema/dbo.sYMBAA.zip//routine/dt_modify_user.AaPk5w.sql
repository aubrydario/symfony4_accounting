
CREATE procedure [dbo].[dt_modify_user]

@typeid		int,
@userid		int,
@name		nvarchar(30),
@vorname	nvarchar(30),
@status			int,
@email	nvarchar(60),
@fax	nvarchar(60),
@handy	nvarchar(60),
@telefon	nvarchar(60),
@strasse	nvarchar(60),
@ort	nvarchar(60),
@plz			int,
@uid	nvarchar(60),
@pwd	nvarchar(60),
@MANr			int,
@WinwareID 			int,
@t_rolle_id			int

AS
SET NOCOUNT ON

declare @temp_id int

--'typeid = 1  new  user ->  insert
--'typeid = 2	 existing user -> update

if (@typeid = 1)
BEGIN
	
	Insert into t_user (t_sprache_id,MANr,uid,pwd,status,name,vorname,strasse,plz,ort,telefon,fax,email,gultigBis,supervisor,winwareID,handy ) values (1,@MANr,@uid,@pwd,@status,@name,@vorname,@strasse,@plz,@ort,@telefon,@fax,@email,'02.01.2020',0,@WinwareID,@handy)

	 set @temp_id = Scope_Identity()

	Insert into t_user_rolle (t_user_id,t_rolle_id) values (@temp_id ,@t_rolle_id)

END

if ( @typeid = 2)
BEGIN
	
	Update t_user set name = @name ,  vorname = @vorname ,	status = @status ,email = @email ,fax = @fax ,handy = @handy ,telefon = @telefon ,strasse = @strasse ,ort = @ort ,	plz = @plz ,uid = @uid ,	pwd = @pwd,	MANr = @MANr ,	WinwareID = @WinwareID where id = @userid
	
END

GO

