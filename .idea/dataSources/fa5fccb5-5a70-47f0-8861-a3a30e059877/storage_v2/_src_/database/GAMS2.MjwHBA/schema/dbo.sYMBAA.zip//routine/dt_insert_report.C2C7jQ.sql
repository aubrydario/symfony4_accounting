CREATE procedure [dbo].[dt_insert_report]

@report_type_id		int,
@file_name		int,
@date			datetime,
@URL			varchar (500),
@owner		int

AS
SET NOCOUNT ON

declare @temp_id int
SET LANGUAGE deutsch

BEGIN
	Insert into t_report (typeID,kundeID,[date],URL,t_user_id) values (@report_type_id,@file_name,@date,@URL,@owner)

SELECT @temp_id = Scope_Identity()
SELECT temp_id = @temp_id

END
GO

