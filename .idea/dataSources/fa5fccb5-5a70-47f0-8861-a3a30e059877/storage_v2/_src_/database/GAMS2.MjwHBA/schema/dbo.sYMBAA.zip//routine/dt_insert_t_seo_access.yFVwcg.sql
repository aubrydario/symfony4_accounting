

CREATE procedure [dbo].[dt_insert_t_seo_access]

@t_url_id				int		=	NULL,
@t_user_id				int		=	NULL,
@begin_optimierung			datetime	=	NULL,
@optimierung_bereit			datetime	=	NULL,
@optimierung_aufgeschaltet		datetime	=	NULL,
@kunde_metas_zusenden			datetime	=	NULL,
@seo_bemerkung				nvarchar(2000)	=	NULL,
@mit_doorway				int		=	NULL,
@alt_text_einf				int		=	NULL,
@zusatzseiten				int		=	NULL,
@sitemap				int		=	NULL,
@anm_open_dir				int		=	NULL,
@akzeptiert				datetime 	=	NULL,
@versendet				datetime	= 	NULL

AS

SET NOCOUNT ON

declare @temp_kw_id int
declare @temp_kw_vorschlag_id int

BEGIN

		Insert into t_kw (t_user_id, datum_akzeptiert) values (@t_user_id, @akzeptiert)

	 			set @temp_kw_id = Scope_Identity()

		Insert into t_kw_vorschlag (t_user_id, vorschlag_versendet) values (@t_user_id, @versendet)

	 			set @temp_kw_vorschlag_id = Scope_Identity()

		Insert into t_seo 
			(t_user_id, t_url_id, begin_optimierung, optimierung_bereit, optimierung_aufgeschaltet, 
			 kunde_metas_zusenden, t_kw_vorschlag_id, t_kw_id,bemerkung, mit_doorway, alt_text_einf,
			 zusatzseiten,sitemap,anm_open_dir)
		Values
			(@t_user_id, @t_url_id, @begin_optimierung, @optimierung_bereit, @optimierung_aufgeschaltet,
			 @kunde_metas_zusenden, @temp_kw_vorschlag_id, @temp_kw_id, @seo_bemerkung, @mit_doorway, 
			 @alt_text_einf, @zusatzseiten, @sitemap, @anm_open_dir)

Select @temp_kw_id, @temp_kw_vorschlag_id
END


GO

