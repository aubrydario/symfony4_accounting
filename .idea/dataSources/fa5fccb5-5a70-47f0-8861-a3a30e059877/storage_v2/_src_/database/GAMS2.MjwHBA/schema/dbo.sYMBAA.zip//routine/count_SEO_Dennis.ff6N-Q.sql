-- =============================================
-- Author: Dennis Skaletz
-- Create date: 25.05.2016
-- Description:	Gibt die  Anzahl SEOs und ZS in 
-- einem bestimmten Monat eines bestimmten 
-- Jahres für einen bestimmten Kunden aus
-- =============================================
CREATE FUNCTION count_SEO_Dennis 
(
	-- Add the parameters for the function here
	@id int,
	@monat int,
	@jahr int

)
RETURNS int
AS
BEGIN

	DECLARE @anzahl int

	SELECT @anzahl = COUNT(optimierung_aufgeschaltet) FROM t_seo

	INNER JOIN t_user
	ON t_user.id = t_seo.t_user_id

	WHERE @id = t_user.id AND @jahr = year(optimierung_aufgeschaltet) AND @monat = month(optimierung_aufgeschaltet)

	RETURN @anzahl
END
GO

