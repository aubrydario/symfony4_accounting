CREATE VIEW dbo.v_heute
AS
SELECT     GETDATE() AS heute
GO

