
CREATE VIEW [dbo].[gn_Clients]
 
AS
	select
		n.id as recipient_id, 
		a.id as address_id, 
		u.id as url_id, 
		t.id as contract_id,
		t.vertragsstart as contract_startdate,
		t.vertragsende as contract_enddate
	from dbo.t_newsletter_email n
		join dbo.t_adresse a on n.email = a.txt_firma_email or n.email = a.txt_ap_email
		join dbo.t_url u on u.t_adresse_id = a.id
		join dbo.t_vertrag_typ t on u.id = t.t_url_id
	where n.abgemeldet is null and (a.adresse_ungueltig is null or a.adresse_ungueltig = 0)
GO

