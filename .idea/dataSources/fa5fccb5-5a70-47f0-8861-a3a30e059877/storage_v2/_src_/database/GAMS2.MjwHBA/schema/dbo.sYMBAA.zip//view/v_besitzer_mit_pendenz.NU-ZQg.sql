CREATE VIEW dbo.v_besitzer_mit_pendenz
AS
SELECT     A.ID
FROM         dbo.t_besitzer AS B INNER JOIN
                      dbo.t_adresse AS A ON A.ID = B.t_adresse_ID INNER JOIN
                      dbo.t_pendenz AS P ON P.t_adresse_ID = B.t_adresse_ID
WHERE     (A.adresse_ungueltig = 0 OR
                      A.adresse_ungueltig IS NULL OR
                      A.adresse_ungueltig = '') AND (A.int_adress_status_ID < 9) AND (P.erledigt <> 1)
GROUP BY A.ID
GO

