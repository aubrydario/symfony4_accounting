CREATE procedure [dbo].[dt_coutry_code]
@abkurz varchar(4)
AS
SET NOCOUNT ON
declare @temp_id int
BEGIN
		if exists(Select id from t_country_code where abkurz = @abkurz )
		BEGIN
				Select id from t_country_code where abkurz = @abkurz
		END
	else 
		BEGIN
				Insert into  t_country_code (abkurz) values (@abkurz)
				SELECT @temp_id = Scope_Identity()
   		 		SELECT temp_id = @temp_id

		END
END
GO

