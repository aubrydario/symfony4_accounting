



CREATE   procedure [dbo].[dt_getActiveUsersList]

@ActUserID 	int

AS
SET NOCOUNT ON

SELECT ('<option value=""' + LTRIM(RTRIM(STR(U.id))) + '""' + CASE U.id WHEN @ActUserID THEN ' selected' ELSE '' END + '>' + LTRIM(RTRIM(STR(U.vorname))) + ' ' + LTRIM(RTRIM(STR(U.name))) + '</option>') FROM t_user U WHERE U.id = @ActUserID AND U.status = 1


GO

