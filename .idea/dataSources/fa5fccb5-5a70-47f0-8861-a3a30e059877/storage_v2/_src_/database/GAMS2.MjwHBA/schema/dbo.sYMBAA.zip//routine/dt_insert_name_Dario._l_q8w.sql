-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description: <Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[dt_insert_name_Dario] 
                @vorname nvarchar(50)
                ,@name nvarchar(50)
AS
BEGIN
                -- SET NOCOUNT ON added to prevent extra result sets from
                -- interfering with SELECT statements.
                SET NOCOUNT ON;

    -- Insert statements for procedure here
                insert into dbo.t_user (vorname, name, kuerzel, GultigBis, Supervisor)
                values(@vorname, @name, lower(LEFT( @vorname, 1 ) + LEFT( @name, 2 )), '30.10.2017', 0)
END
GO

