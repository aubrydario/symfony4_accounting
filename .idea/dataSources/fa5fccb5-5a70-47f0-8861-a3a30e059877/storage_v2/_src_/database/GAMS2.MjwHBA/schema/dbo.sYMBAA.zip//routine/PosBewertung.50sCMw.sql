

CREATE FUNCTION [dbo].[PosBewertung](@reportID int)
RETURNS int
AS
BEGIN
	
declare @bewertung int
declare @web_1 int
declare @web_2 int
declare @deutsch_1 int
declare @deutsch_2 int
declare @schweiz_1 int
declare @schweiz_2 int
declare @gesamt int

set @bewertung = 0
set @web_1 = 0
set @web_2 = 0
set @deutsch_1 = 0
set @deutsch_2 = 0
set @schweiz_1 = 0
set @schweiz_2 = 0
set @gesamt = 0
	
SELECT @gesamt = count(DISTINCT (RS.keywordsID))
FROM         dbo.t_report_spec AS RS INNER JOIN
					  dbo.t_ranking AS R ON RS.rankingID = R.ID
WHERE     (RS.reportID = @reportID)
and  ((RS.engineID=163 AND (page=1 or page=2))
OR  (RS.engineID=28 AND (page=1 or page=2))
or  (RS.engineID=27 AND (page=1 or page=2)))

if @gesamt = 0
begin
return 0
end 


	SELECT @schweiz_1 = dbo.[getPosPerSM] (@reportID, 163, 1) 

	if @schweiz_1 > 7 
	BEGIN
		return 1
	END 
	ELSE
	BEGIN
		SELECT @schweiz_2 = dbo.[getPosPerSM] (@reportID, 163, 2)
		if @schweiz_1 + @schweiz_2 > 7 
		BEGIN 
			return 1
		END
		ELSE
		BEGIN
			SELECT @deutsch_1 = dbo.[getPosPerSM] (@reportID, 28, 1) 
			if @deutsch_1 > 7 
			BEGIN 
				return 1
			END 
			ELSE
			BEGIN
				SELECT @deutsch_2 = dbo.[getPosPerSM] (@reportID, 28, 2) 
				if @deutsch_1 + @deutsch_2 > 7 
				BEGIN
					return 1
				END 
				ELSE
				BEGIN
					SELECT @web_1 = dbo.[getPosPerSM] (@reportID, 27, 1) 
					if @web_1 > 7 
					BEGIN
						return 1
					END
					ELSE
					BEGIN
						SELECT @web_2 = dbo.[getPosPerSM] (@reportID, 27, 1) 
						if @web_1 + @web_2 > 7 
						BEGIN
							return 1
						END
					END
				END
			END
		END
	END

		
	RETURN @bewertung

END


GO

