
CREATE FUNCTION [dbo].[getPosPerSM](@t_report_id int, @t_engine_id int, @page int) 
RETURNS int
AS
BEGIN
DECLARE @anzPos int
set @anzPos = 0
SELECT @anzPos = count(DISTINCT (RS.keywordsID))
FROM         dbo.t_report_spec AS RS INNER JOIN
					  dbo.t_ranking AS R ON RS.rankingID = R.ID
WHERE     (RS.reportID = @t_report_id)and  RS.engineID=@t_engine_id AND page=@page
	
	RETURN @anzPos

END

GO

