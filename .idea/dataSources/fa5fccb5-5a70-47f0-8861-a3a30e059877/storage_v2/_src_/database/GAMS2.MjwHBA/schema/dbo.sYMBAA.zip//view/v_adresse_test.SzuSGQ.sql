CREATE VIEW dbo.v_adresse_test
AS
SELECT     txt_www
FROM         dbo.t_adresse
WHERE     (txt_www LIKE '%globo%')
GO

