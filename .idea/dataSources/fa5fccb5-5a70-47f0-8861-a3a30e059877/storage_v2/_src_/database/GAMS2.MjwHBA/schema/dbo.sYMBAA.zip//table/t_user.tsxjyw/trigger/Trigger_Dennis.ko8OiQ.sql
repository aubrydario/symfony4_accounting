CREATE TRIGGER [dbo].[Trigger_Dennis]
ON [dbo].[t_user]
	FOR INSERT 
AS 

UPDATE t_user 
SET GultigBis = DATEADD(year, 5, GultigBis) 
WHERE ID = @@IDENTITY
GO

