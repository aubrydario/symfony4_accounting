
CREATE PROCEDURE [dbo].[SpeerzeitUebertragen]

AS

SET NOCOUNT ON

BEGIN
          /* Deklaration der Variablen */
       declare @datum as datetime
       declare @von as datetime
       declare @bis as datetime
       declare @t_adresse_id as int
       declare @ca_id as int
       declare @bemerkungen as varchar(8000)
       declare @status as int
       declare @del as int
       declare @terminart as int
       declare @hp_pflege as int 

          /* Deklaration des Cusors*/
       declare mycursor CURSOR FOR
       
          /* Auslesen der relevanten Zellen von der Tabelle t_termin */
          SELECT datum, von, bis, t_adresse_id, CA_id, bemerkungen, status, del, terminart, hp_pflege
       from t_termin
       
          /* Definition Sperrzeiten anhand der gesetzten Termine von Robert Camathias*/
          WHERE AG_id = 320 AND t_adresse_id = 0
       AND
       von
       BETWEEN
       '01.09.2012'
       AND
       '31.12.2012'
       
          OPEN mycursor
       
          /* Setzt den Cursor auf die Aktuelle Zeile, liest die Daten aus und setzt die Werte in die Variabeln ein */
          FETCH NEXT FROM mycursor INTO @datum, @von, @bis, @t_adresse_id, @ca_id, @bemerkungen, @status, @del, @terminart, @hp_pflege
       WHILE @@FETCH_STATUS = 0
       
          /* Start der Insert-Schlaufe */
          BEGIN

                    /* Insertsyntax für die ausgelesenen Zellen. Die Sperrzeiten werden für jeden Sales, anhand der ausgelesenen
                    Daten, eingetragen  */
       
                    
                    INSERT INTO t_termin(datum, von, bis, t_adresse_id, CA_id, AG_id, bemerkungen, status, del, terminart, hp_pflege)
             VALUES(getdate(), @von, @bis, @t_adresse_id, @ca_id, 123, @bemerkungen, @status, @del, @terminart, @hp_pflege)
                    
                     INSERT INTO t_termin(datum, von, bis, t_adresse_id, CA_id, AG_id, bemerkungen, status, del, terminart, hp_pflege)
             VALUES(getdate(), @von, @bis, @t_adresse_id, @ca_id, 219, @bemerkungen, @status, @del, @terminart, @hp_pflege)
                    
                     INSERT INTO t_termin(datum, von, bis, t_adresse_id, CA_id, AG_id, bemerkungen, status, del, terminart, hp_pflege)
             VALUES(getdate(), @von, @bis, @t_adresse_id, @ca_id, 248, @bemerkungen, @status, @del, @terminart, @hp_pflege)

                    INSERT INTO t_termin(datum, von, bis, t_adresse_id, CA_id, AG_id, bemerkungen, status, del, terminart, hp_pflege)
             VALUES(getdate(), @von, @bis, @t_adresse_id, @ca_id, 314, @bemerkungen, @status, @del, @terminart, @hp_pflege)


        
          /* Setzt den Cursor auf die nächste Zeile */    
       FETCH NEXT FROM mycursor INTO @datum, @von, @bis, @t_adresse_id, @ca_id, @bemerkungen, @status, @del, @terminart, @hp_pflege
       
          END
       
          CLOSE mycursor
          DEALLOCATE mycursor
END


GO

