-- =============================================
-- Author:		<Dennis Skaletz>
-- Create date: <25.05.2016>
-- Description:	Vorname und Nachname müssen eingegeben werden, generiert davon einen 3 Langen Kürzel
--				1 Char vom Vorname, 2 Chars vom Nachname) und fügt diese in t_user ein
-- =============================================
CREATE PROCEDURE [dbo].[dt_insert_name_DENNIS] 
	-- Add the parameters for the stored procedure here
	@vorname varchar(20), 
	@nachname varchar(20)
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	INSERT INTO t_user (vorname, name, kuerzel, gultigBis, Supervisor)
	VALUES(@vorname, @nachname, LEFT(@vorname, 1) + LEFT(@nachname, 2), '30.07.2050', 0)
END
GO

