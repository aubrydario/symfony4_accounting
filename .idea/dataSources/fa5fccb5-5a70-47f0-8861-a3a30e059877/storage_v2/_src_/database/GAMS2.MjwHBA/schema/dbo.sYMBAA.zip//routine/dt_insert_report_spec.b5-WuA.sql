CREATE procedure [dbo].[dt_insert_report_spec]

@engine_id 			int,
@last_ranking_id 	int,
@last_report_id 	int,
@last_keywords_id	int,
@firstsubmit		datetime,
@lastsubmit		datetime,
@submitcount		int


AS

SET NOCOUNT ON
SET LANGUAGE deutsch
BEGIN

Insert into t_report_spec (engineID,rankingID,reportID,keywordsID,firstsubmit,lastsubmit,submitcount) values (@engine_id,@last_ranking_id,@last_report_id,@last_keywords_id,@firstsubmit,@lastsubmit,@submitcount)

END
GO

