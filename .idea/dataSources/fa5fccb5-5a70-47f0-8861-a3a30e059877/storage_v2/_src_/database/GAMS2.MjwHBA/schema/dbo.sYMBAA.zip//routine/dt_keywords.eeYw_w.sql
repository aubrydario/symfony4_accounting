
CREATE procedure [dbo].[dt_keywords]

@keywords varchar(200)

AS
SET NOCOUNT ON

declare @temp_id int

set @keywords = replace(@keywords, 'Ã¤', 'ä')
set @keywords = replace(@keywords, 'Ã¼', 'ü')
set @keywords = replace(@keywords, 'Ãœ', 'Ü')
set @keywords = replace(@keywords, 'Ã¶', 'ö')
set @keywords = replace(@keywords, 'Ã„', 'Ä')
set @keywords = replace(@keywords, 'Ã´', 'ô')
set @keywords = replace(@keywords, 'Ã©', 'é')
set @keywords = replace(@keywords, 'Ã–', 'Ö')
set @keywords = replace(@keywords, 'Ã ', 'à')

	if exists(Select id from t_keywords_set where keywords = @keywords)
		BEGIN
				Select id from t_keywords_set where keywords = @keywords
		END
	else 
		BEGIN
				Insert into  t_keywords_set (keywords) values (@keywords)
				SELECT @temp_id = Scope_Identity()
   		 		SELECT temp_id = @temp_id

		END

GO

