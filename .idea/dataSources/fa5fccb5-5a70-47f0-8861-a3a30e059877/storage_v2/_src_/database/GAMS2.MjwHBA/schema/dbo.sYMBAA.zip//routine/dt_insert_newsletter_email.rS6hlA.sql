CREATE PROCEDURE [dbo].[dt_insert_newsletter_email]
@vorname nvarchar(50),
@nachname nvarchar(50),
@anrede int,
@email nvarchar(100),
@angemeldet datetime,
@abgemeldet datetime

AS

begin
	SET NOCOUNT ON;
	declare @tempId int

	if exists(Select id from t_newsletter_email where email = @email)
	begin
		SET @tempId = (Select id from t_newsletter_email where email = @email)
		if @vorname <> '' and len(@vorname) > 2
		begin
			Update t_newsletter_email set vorname = @vorname where id = @tempId
		end
		
		if @nachname <> '' and len(@nachname) > 2
		begin
			Update t_newsletter_email set nachname = @nachname where id = @tempId
		end
		
		if @anrede <> '' 
		begin
			Update t_newsletter_email set anrede = @anrede where id = @tempId
		end

		/*
		if @angemeldet <> '' 
		begin
			Update t_newsletter_email set angemeldet = @angemeldet where id = @tempId
		end
		*/
		
		if @abgemeldet <> ''
		begin
			Update t_newsletter_email set abgemeldet = @abgemeldet where id = @tempId
		end
		else
		begin
			Update t_newsletter_email set abgemeldet = NULL where id = @tempId
		end
	end
	else 
	begin
		if dbo.istemailgueltig(@email) = 1
		begin
			Insert into t_newsletter_email(vorname, nachname, anrede, email, angemeldet) 
			Values(@vorname, @nachname, @anrede, @email, GETDATE())	
		end
	 end
end
GO

