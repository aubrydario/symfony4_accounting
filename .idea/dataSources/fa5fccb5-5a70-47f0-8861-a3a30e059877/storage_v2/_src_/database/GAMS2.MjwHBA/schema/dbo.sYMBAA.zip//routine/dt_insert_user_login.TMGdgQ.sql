CREATE procedure [dbo].[dt_insert_user_login]

@t_user_id int,
@login_datum smalldatetime

AS
SET NOCOUNT ON


	if exists(Select t_user_id from t_user_login where t_user_id = @t_user_id)
		BEGIN
				Update t_user_login SET login_datum= @login_datum where t_user_id = @t_user_id 

		END
	else
		BEGIN
				Insert into t_user_login (t_user_id,login_datum) values (@t_user_id,@login_datum)
		END
GO

