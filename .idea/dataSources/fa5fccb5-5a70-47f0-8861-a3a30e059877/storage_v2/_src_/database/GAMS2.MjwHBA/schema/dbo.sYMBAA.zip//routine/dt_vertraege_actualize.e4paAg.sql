


CREATE PROCEDURE [dbo].[dt_vertraege_actualize]

AS

SET NOCOUNT ON

DECLARE @v_count INT
DECLARE @url_id BIGINT
DECLARE @a_id BIGINT

DECLARE vertraege CURSOR FOR
	SELECT
		COUNT(t_url_id), t_url_id
	FROM
		t_vertrag_typ
	GROUP BY
		t_url_id
	ORDER BY
		t_url_id ASC

OPEN vertraege
	FETCH NEXT FROM vertraege INTO @v_count, @url_id
	WHILE @@FETCH_STATUS = 0
		BEGIN
		if(@v_count > 1)
			BEGIN
				DECLARE urls CURSOR FOR
					SELECT
						TOP 1 A.id
					FROM
						t_adresse A
						INNER JOIN t_url U ON A.id = U.t_adresse_id
					WHERE
						U.id = @url_id

				OPEN urls
					FETCH NEXT FROM urls INTO @a_id
					WHILE @@FETCH_STATUS = 0
						BEGIN
							UPDATE t_adresse SET int_adress_status_id = 10 WHERE id = @a_id
							FETCH NEXT FROM urls INTO @a_id
						END
				CLOSE urls
				DEALLOCATE urls
			END
			FETCH NEXT FROM vertraege INTO @v_count, @url_id
		END

CLOSE vertraege
DEALLOCATE vertraege


GO

